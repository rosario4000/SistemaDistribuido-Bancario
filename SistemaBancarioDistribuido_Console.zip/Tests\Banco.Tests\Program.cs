using Banco.Application.Services;
using Banco.Core.Enums;
using Banco.Infrastructure.Persistence;

var testDataDirectory = Path.Combine(Directory.GetCurrentDirectory(), "TestData");
Directory.CreateDirectory(testDataDirectory);
var dataPath = Path.Combine(testDataDirectory, $"banco-tests-{Guid.NewGuid():N}.json");

try
{
    var repository = new JsonBancoRepository(dataPath);
    var authService = new AuthService(repository);
    var bancoService = new BancoService(repository);

    var login = authService.Autenticar("admin", "admin123");
    Assert(login.Sucesso && login.Valor is not null, "Login inicial deve funcionar.");
    var adminId = login.Valor!.Id;

    var cliente1 = bancoService.CadastrarCliente(adminId, "Ana Manuel", "BI001", "923000001", "ana@banco.ao", "Luanda");
    var cliente2 = bancoService.CadastrarCliente(adminId, "Jose Pedro", "BI002", "923000002", "jose@banco.ao", "Benguela");
    Assert(cliente1.Sucesso && cliente1.Valor is not null, "Cliente 1 deve ser cadastrado.");
    Assert(cliente2.Sucesso && cliente2.Valor is not null, "Cliente 2 deve ser cadastrado.");

    var agencia = bancoService.ListarAgencias().First();
    var conta1 = bancoService.AbrirConta(adminId, cliente1.Valor!.Id, agencia.Id, TipoConta.Corrente, 1000m);
    var conta2 = bancoService.AbrirConta(adminId, cliente2.Valor!.Id, agencia.Id, TipoConta.Poupanca, 200m);
    Assert(conta1.Sucesso && conta1.Valor is not null, "Conta 1 deve ser aberta.");
    Assert(conta2.Sucesso && conta2.Valor is not null, "Conta 2 deve ser aberta.");

    Assert(bancoService.Depositar(adminId, conta1.Valor!.Numero, 500m, "Deposito teste").Sucesso, "Deposito deve funcionar.");
    Assert(bancoService.Levantar(adminId, conta1.Valor.Numero, 250m, "Levantamento teste").Sucesso, "Levantamento deve funcionar.");
    Assert(bancoService.Transferir(adminId, conta1.Valor.Numero, conta2.Valor!.Numero, 300m, "Transferencia teste").Sucesso, "Transferencia deve funcionar.");
    Assert(!bancoService.Levantar(adminId, conta1.Valor.Numero, 99999m, "Saldo insuficiente").Sucesso, "Levantamento sem saldo deve falhar.");

    var contaOrigemAtual = bancoService.ListarContas().First(conta => conta.Id == conta1.Valor.Id);
    var contaDestinoAtual = bancoService.ListarContas().First(conta => conta.Id == conta2.Valor.Id);
    Assert(contaOrigemAtual.Saldo == 950m, "Saldo da origem deve fechar em 950.");
    Assert(contaDestinoAtual.Saldo == 500m, "Saldo do destino deve fechar em 500.");

    var extrato = bancoService.Extrato(conta1.Valor.Numero);
    Assert(extrato.Count >= 4, "Extrato da origem deve ter abertura, deposito, levantamento e transferencia.");

    var dashboard = bancoService.ObterDashboard();
    Assert(dashboard.TotalClientes == 2, "Dashboard deve contabilizar clientes.");
    Assert(dashboard.TotalContas == 2, "Dashboard deve contabilizar contas.");
    Assert(dashboard.TotalTransacoes >= 5, "Dashboard deve contabilizar transacoes.");

    Console.WriteLine("Todos os testes passaram.");
}
finally
{
    if (File.Exists(dataPath))
    {
        File.Delete(dataPath);
    }
}

static void Assert(bool condition, string message)
{
    if (!condition)
    {
        throw new InvalidOperationException(message);
    }
}
