namespace Banco.Core.Entities;

public sealed class Cliente
{
    public int Id { get; set; }
    public string NomeCompleto { get; set; } = string.Empty;
    public string Documento { get; set; } = string.Empty;
    public DateOnly? DataNascimento { get; set; }
    public string Telefone { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Morada { get; set; } = string.Empty;
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
    public DateTime? AtualizadoEm { get; set; }
}
