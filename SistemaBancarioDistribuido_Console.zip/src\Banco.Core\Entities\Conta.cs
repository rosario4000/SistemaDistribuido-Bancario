using Banco.Core.Enums;

namespace Banco.Core.Entities;

public sealed class Conta
{
    public int Id { get; set; }
    public string Numero { get; set; } = string.Empty;
    public int ClienteId { get; set; }
    public int AgenciaId { get; set; }
    public TipoConta Tipo { get; set; }
    public EstadoConta Estado { get; set; } = EstadoConta.Ativa;
    public decimal Saldo { get; set; }
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
}
