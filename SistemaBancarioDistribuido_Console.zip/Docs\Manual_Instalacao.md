# Manual de Instalacao e Uso

## Requisitos

- .NET SDK 10 ou superior
- SQL Server e SQL Server Management Studio, caso queira executar os scripts da pasta `Database`

## Executar em modo demonstracao

1. Abra o terminal na pasta do projeto.
2. Execute:

```powershell
dotnet run --project src\Banco.ConsoleApp
```

3. Entre com:

```text
admin
admin123
```

## Fluxo sugerido para demonstracao

1. Cadastrar dois clientes.
2. Abrir uma conta para cada cliente.
3. Fazer um deposito na primeira conta.
4. Fazer um levantamento.
5. Transferir valor da primeira para a segunda conta.
6. Consultar extrato.
7. Abrir dashboard.
8. Abrir auditoria.

## Preparar SQL Server

Execute os scripts nesta ordem:

```text
Database/01_schema.sql
Database/02_seed.sql
Database/03_procedures.sql
```

Depois configure os computadores das agencias para acederem ao SQL Server central pela rede, conforme a arquitetura do guiao.
