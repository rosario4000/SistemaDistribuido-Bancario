using Banco.Application.Common;
using Banco.Application.Interfaces;
using Banco.Application.Security;
using Banco.Core.Entities;

namespace Banco.Application.Services;

public sealed class AuthService
{
    private readonly IBancoRepository repository;

    public AuthService(IBancoRepository repository)
    {
        this.repository = repository;
    }

    public Resultado<UtilizadorInterno> Autenticar(string nomeUsuario, string senha)
    {
        var utilizador = repository.ObterUtilizadorPorNome(nomeUsuario.Trim());
        if (utilizador is null || !utilizador.Ativo)
        {
            return Resultado<UtilizadorInterno>.Falha("Utilizador ou senha invalida.");
        }

        var senhaValida = PasswordHasher.Verificar(senha, utilizador.SenhaHash, utilizador.SenhaSalt);
        if (!senhaValida)
        {
            return Resultado<UtilizadorInterno>.Falha("Utilizador ou senha invalida.");
        }

        return Resultado<UtilizadorInterno>.Ok(utilizador, $"Bem-vindo, {utilizador.NomeCompleto}.");
    }
}
