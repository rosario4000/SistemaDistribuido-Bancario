# Arquitetura

## Visao distribuida

```mermaid
flowchart LR
    A["Agencia Luanda - Console C#"] --> DB["SQL Server Central"]
    B["Agencia Benguela - Console C#"] --> DB
    C["Agencia Cabinda - Console C#"] --> DB
    D["Sede Central Uige - Console C#"] --> DB
```

## Camadas

- `Banco.Core`: contem entidades como Cliente, Conta, Agencia, Utilizador, Transacao, Transferencia e Auditoria.
- `Banco.Application`: contem regras de negocio, login, validacoes, dashboard e contratos de repositorio.
- `Banco.Infrastructure`: contem a persistencia. Nesta versao usa JSON para rodar sem configuracao externa.
- `Banco.ConsoleApp`: contem os menus de terminal.
- `Database`: contem os scripts SQL Server para a base central.

## Observacao sobre SQL Server

O guiao pede que varias agencias acedam a uma base remota. Para isso, em producao, a interface `IBancoRepository` deve ganhar uma implementacao SQL Server. A aplicacao de console ja esta desacoplada dessa decisao: os menus chamam os servicos, e os servicos chamam o repositorio.
