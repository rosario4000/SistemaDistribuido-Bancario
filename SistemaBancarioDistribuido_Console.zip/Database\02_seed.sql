USE SistemaBancarioDistribuido;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Agencias)
BEGIN
    INSERT INTO dbo.Agencias (Codigo, Nome, Provincia, Endereco)
    VALUES
        ('LAD', N'Agencia Luanda', N'Luanda', N'Luanda'),
        ('BGU', N'Agencia Benguela', N'Benguela', N'Benguela'),
        ('CAB', N'Agencia Cabinda', N'Cabinda', N'Cabinda'),
        ('UIG', N'Sede Central Uige', N'Uige', N'Uige');
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Utilizadores WHERE NomeUsuario = N'admin')
BEGIN
    DECLARE @Salt VARCHAR(64) = '53414C5444454D4F313233343536373839';
    DECLARE @Entrada VARCHAR(200) = CONCAT(@Salt, ':admin123');
    DECLARE @Hash VARCHAR(64) = CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', @Entrada), 2);

    INSERT INTO dbo.Utilizadores (NomeCompleto, NomeUsuario, Perfil, AgenciaId, SenhaHash, SenhaSalt)
    SELECT N'Administrador Geral', N'admin', 'Administrador', Id, @Hash, @Salt
    FROM dbo.Agencias
    WHERE Codigo = 'UIG';
END
GO
