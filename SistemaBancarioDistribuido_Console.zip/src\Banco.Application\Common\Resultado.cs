namespace Banco.Application.Common;

public class Resultado
{
    protected Resultado(bool sucesso, string mensagem)
    {
        Sucesso = sucesso;
        Mensagem = mensagem;
    }

    public bool Sucesso { get; }
    public string Mensagem { get; }

    public static Resultado Ok(string mensagem = "Operacao concluida com sucesso.") => new(true, mensagem);
    public static Resultado Falha(string mensagem) => new(false, mensagem);
}

public sealed class Resultado<T> : Resultado
{
    private Resultado(bool sucesso, string mensagem, T? valor)
        : base(sucesso, mensagem)
    {
        Valor = valor;
    }

    public T? Valor { get; }

    public static Resultado<T> Ok(T valor, string mensagem = "Operacao concluida com sucesso.") => new(true, mensagem, valor);
    public new static Resultado<T> Falha(string mensagem) => new(false, mensagem, default);
}
