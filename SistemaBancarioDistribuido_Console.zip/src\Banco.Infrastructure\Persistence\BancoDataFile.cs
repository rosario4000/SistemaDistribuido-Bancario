using Banco.Core.Entities;

namespace Banco.Infrastructure.Persistence;

internal sealed class BancoDataFile
{
    public List<Agencia> Agencias { get; set; } = [];
    public List<Cliente> Clientes { get; set; } = [];
    public List<Conta> Contas { get; set; } = [];
    public List<UtilizadorInterno> Utilizadores { get; set; } = [];
    public List<Transacao> Transacoes { get; set; } = [];
    public List<Transferencia> Transferencias { get; set; } = [];
    public List<Auditoria> Auditoria { get; set; } = [];
    public Dictionary<string, int> Sequencias { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}
