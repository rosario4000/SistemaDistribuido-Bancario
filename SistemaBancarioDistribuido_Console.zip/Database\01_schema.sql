IF DB_ID(N'SistemaBancarioDistribuido') IS NULL
BEGIN
    CREATE DATABASE SistemaBancarioDistribuido;
END
GO

USE SistemaBancarioDistribuido;
GO

IF OBJECT_ID(N'dbo.Transferencias', N'U') IS NOT NULL DROP TABLE dbo.Transferencias;
IF OBJECT_ID(N'dbo.Transacoes', N'U') IS NOT NULL DROP TABLE dbo.Transacoes;
IF OBJECT_ID(N'dbo.Auditoria', N'U') IS NOT NULL DROP TABLE dbo.Auditoria;
IF OBJECT_ID(N'dbo.Contas', N'U') IS NOT NULL DROP TABLE dbo.Contas;
IF OBJECT_ID(N'dbo.Utilizadores', N'U') IS NOT NULL DROP TABLE dbo.Utilizadores;
IF OBJECT_ID(N'dbo.Clientes', N'U') IS NOT NULL DROP TABLE dbo.Clientes;
IF OBJECT_ID(N'dbo.Agencias', N'U') IS NOT NULL DROP TABLE dbo.Agencias;
GO

CREATE TABLE dbo.Agencias
(
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Agencias PRIMARY KEY,
    Codigo VARCHAR(10) NOT NULL CONSTRAINT UQ_Agencias_Codigo UNIQUE,
    Nome NVARCHAR(120) NOT NULL,
    Provincia NVARCHAR(80) NOT NULL,
    Endereco NVARCHAR(200) NULL,
    Ativa BIT NOT NULL CONSTRAINT DF_Agencias_Ativa DEFAULT (1),
    CriadoEm DATETIME2 NOT NULL CONSTRAINT DF_Agencias_CriadoEm DEFAULT (SYSUTCDATETIME())
);

CREATE TABLE dbo.Clientes
(
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Clientes PRIMARY KEY,
    NomeCompleto NVARCHAR(160) NOT NULL,
    Documento NVARCHAR(40) NOT NULL CONSTRAINT UQ_Clientes_Documento UNIQUE,
    DataNascimento DATE NULL,
    Telefone NVARCHAR(40) NULL,
    Email NVARCHAR(120) NULL,
    Morada NVARCHAR(220) NULL,
    CriadoEm DATETIME2 NOT NULL CONSTRAINT DF_Clientes_CriadoEm DEFAULT (SYSUTCDATETIME()),
    AtualizadoEm DATETIME2 NULL
);

CREATE TABLE dbo.Utilizadores
(
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Utilizadores PRIMARY KEY,
    NomeCompleto NVARCHAR(160) NOT NULL,
    NomeUsuario NVARCHAR(60) NOT NULL CONSTRAINT UQ_Utilizadores_NomeUsuario UNIQUE,
    Perfil VARCHAR(30) NOT NULL,
    AgenciaId INT NULL,
    SenhaHash VARCHAR(64) NOT NULL,
    SenhaSalt VARCHAR(64) NOT NULL,
    Ativo BIT NOT NULL CONSTRAINT DF_Utilizadores_Ativo DEFAULT (1),
    CriadoEm DATETIME2 NOT NULL CONSTRAINT DF_Utilizadores_CriadoEm DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_Utilizadores_Agencias FOREIGN KEY (AgenciaId) REFERENCES dbo.Agencias(Id),
    CONSTRAINT CK_Utilizadores_Perfil CHECK (Perfil IN ('Operador', 'Gerente', 'Auditor', 'Administrador'))
);

CREATE TABLE dbo.Contas
(
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Contas PRIMARY KEY,
    Numero VARCHAR(30) NOT NULL CONSTRAINT UQ_Contas_Numero UNIQUE,
    ClienteId INT NOT NULL,
    AgenciaId INT NOT NULL,
    Tipo VARCHAR(20) NOT NULL,
    Estado VARCHAR(20) NOT NULL CONSTRAINT DF_Contas_Estado DEFAULT ('Ativa'),
    Saldo DECIMAL(18,2) NOT NULL CONSTRAINT DF_Contas_Saldo DEFAULT (0),
    CriadoEm DATETIME2 NOT NULL CONSTRAINT DF_Contas_CriadoEm DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_Contas_Clientes FOREIGN KEY (ClienteId) REFERENCES dbo.Clientes(Id),
    CONSTRAINT FK_Contas_Agencias FOREIGN KEY (AgenciaId) REFERENCES dbo.Agencias(Id),
    CONSTRAINT CK_Contas_Tipo CHECK (Tipo IN ('Corrente', 'Poupanca')),
    CONSTRAINT CK_Contas_Estado CHECK (Estado IN ('Ativa', 'Bloqueada', 'Encerrada')),
    CONSTRAINT CK_Contas_Saldo CHECK (Saldo >= 0)
);

CREATE TABLE dbo.Transacoes
(
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Transacoes PRIMARY KEY,
    ContaId INT NOT NULL,
    AgenciaId INT NOT NULL,
    UtilizadorId INT NOT NULL,
    Tipo VARCHAR(40) NOT NULL,
    Valor DECIMAL(18,2) NOT NULL,
    SaldoApos DECIMAL(18,2) NOT NULL,
    Referencia VARCHAR(80) NOT NULL,
    Descricao NVARCHAR(250) NULL,
    CriadoEm DATETIME2 NOT NULL CONSTRAINT DF_Transacoes_CriadoEm DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_Transacoes_Contas FOREIGN KEY (ContaId) REFERENCES dbo.Contas(Id),
    CONSTRAINT FK_Transacoes_Agencias FOREIGN KEY (AgenciaId) REFERENCES dbo.Agencias(Id),
    CONSTRAINT FK_Transacoes_Utilizadores FOREIGN KEY (UtilizadorId) REFERENCES dbo.Utilizadores(Id),
    CONSTRAINT CK_Transacoes_Tipo CHECK (Tipo IN ('Abertura', 'Deposito', 'Levantamento', 'TransferenciaEnviada', 'TransferenciaRecebida')),
    CONSTRAINT CK_Transacoes_Valor CHECK (Valor > 0)
);

CREATE TABLE dbo.Transferencias
(
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Transferencias PRIMARY KEY,
    ContaOrigemId INT NOT NULL,
    ContaDestinoId INT NOT NULL,
    UtilizadorId INT NOT NULL,
    Valor DECIMAL(18,2) NOT NULL,
    Referencia VARCHAR(80) NOT NULL CONSTRAINT UQ_Transferencias_Referencia UNIQUE,
    CriadoEm DATETIME2 NOT NULL CONSTRAINT DF_Transferencias_CriadoEm DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_Transferencias_Origem FOREIGN KEY (ContaOrigemId) REFERENCES dbo.Contas(Id),
    CONSTRAINT FK_Transferencias_Destino FOREIGN KEY (ContaDestinoId) REFERENCES dbo.Contas(Id),
    CONSTRAINT FK_Transferencias_Utilizadores FOREIGN KEY (UtilizadorId) REFERENCES dbo.Utilizadores(Id),
    CONSTRAINT CK_Transferencias_Valor CHECK (Valor > 0),
    CONSTRAINT CK_Transferencias_Contas CHECK (ContaOrigemId <> ContaDestinoId)
);

CREATE TABLE dbo.Auditoria
(
    Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Auditoria PRIMARY KEY,
    UtilizadorId INT NULL,
    AgenciaId INT NULL,
    Acao VARCHAR(40) NOT NULL,
    Entidade VARCHAR(80) NOT NULL,
    EntidadeId INT NULL,
    Detalhes NVARCHAR(300) NULL,
    CriadoEm DATETIME2 NOT NULL CONSTRAINT DF_Auditoria_CriadoEm DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_Auditoria_Utilizadores FOREIGN KEY (UtilizadorId) REFERENCES dbo.Utilizadores(Id),
    CONSTRAINT FK_Auditoria_Agencias FOREIGN KEY (AgenciaId) REFERENCES dbo.Agencias(Id)
);
GO

CREATE INDEX IX_Contas_ClienteId ON dbo.Contas(ClienteId);
CREATE INDEX IX_Transacoes_ContaId_CriadoEm ON dbo.Transacoes(ContaId, CriadoEm DESC);
CREATE INDEX IX_Auditoria_CriadoEm ON dbo.Auditoria(CriadoEm DESC);
GO
