namespace Banco.Core.Entities;

public sealed class Transferencia
{
    public int Id { get; set; }
    public int ContaOrigemId { get; set; }
    public int ContaDestinoId { get; set; }
    public int UtilizadorId { get; set; }
    public decimal Valor { get; set; }
    public string Referencia { get; set; } = string.Empty;
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
}
