using Banco.Core.Enums;

namespace Banco.Core.Entities;

public sealed class UtilizadorInterno
{
    public int Id { get; set; }
    public string NomeCompleto { get; set; } = string.Empty;
    public string NomeUsuario { get; set; } = string.Empty;
    public PerfilUtilizador Perfil { get; set; } = PerfilUtilizador.Operador;
    public int? AgenciaId { get; set; }
    public string SenhaHash { get; set; } = string.Empty;
    public string SenhaSalt { get; set; } = string.Empty;
    public bool Ativo { get; set; } = true;
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
}
