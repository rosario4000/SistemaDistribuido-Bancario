namespace Banco.Core.Enums;

public enum PerfilUtilizador
{
    Operador = 1,
    Gerente = 2,
    Auditor = 3,
    Administrador = 4
}
