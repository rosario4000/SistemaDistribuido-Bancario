namespace Banco.Core.Entities;

public sealed class DashboardResumo
{
    public int TotalClientes { get; set; }
    public int TotalContas { get; set; }
    public int TotalAgencias { get; set; }
    public decimal SaldoGlobal { get; set; }
    public decimal VolumeTransacoes { get; set; }
    public int TotalTransacoes { get; set; }
}
