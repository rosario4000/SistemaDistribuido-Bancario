namespace Banco.Core.Enums;

public enum TipoTransacao
{
    Abertura = 1,
    Deposito = 2,
    Levantamento = 3,
    TransferenciaEnviada = 4,
    TransferenciaRecebida = 5
}
