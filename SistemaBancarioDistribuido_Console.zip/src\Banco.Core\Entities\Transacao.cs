using Banco.Core.Enums;

namespace Banco.Core.Entities;

public sealed class Transacao
{
    public int Id { get; set; }
    public int ContaId { get; set; }
    public int AgenciaId { get; set; }
    public int UtilizadorId { get; set; }
    public TipoTransacao Tipo { get; set; }
    public decimal Valor { get; set; }
    public decimal SaldoApos { get; set; }
    public string Referencia { get; set; } = string.Empty;
    public string Descricao { get; set; } = string.Empty;
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
}
