namespace Banco.Core.Entities;

public sealed class Agencia
{
    public int Id { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Nome { get; set; } = string.Empty;
    public string Provincia { get; set; } = string.Empty;
    public string Endereco { get; set; } = string.Empty;
    public bool Ativa { get; set; } = true;
}
