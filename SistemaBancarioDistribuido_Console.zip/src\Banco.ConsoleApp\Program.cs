using System.Globalization;
using System.Text;
using Banco.Application.Common;
using Banco.Application.Services;
using Banco.Core.Entities;
using Banco.Core.Enums;
using Banco.Infrastructure.Persistence;

namespace Banco.ConsoleApp;

internal static class Program
{
    private static void Main()
    {
        var dataPath = Environment.GetEnvironmentVariable("BANCO_DATA_PATH");
        if (string.IsNullOrWhiteSpace(dataPath))
        {
            dataPath = Path.Combine(Directory.GetCurrentDirectory(), "Data", "banco-data.json");
        }

        var repository = new JsonBancoRepository(dataPath);
        var authService = new AuthService(repository);
        var bancoService = new BancoService(repository);

        var app = new ConsoleBankApplication(authService, bancoService, dataPath);
        app.Run();
    }
}

internal sealed class ConsoleBankApplication
{
    private readonly AuthService authService;
    private readonly BancoService bancoService;
    private readonly string dataPath;
    private UtilizadorInterno? utilizadorAtual;

    public ConsoleBankApplication(AuthService authService, BancoService bancoService, string dataPath)
    {
        this.authService = authService;
        this.bancoService = bancoService;
        this.dataPath = dataPath;
    }

    public void Run()
    {
        Console.Title = "Sistema Bancario Distribuido - Console";
        while (true)
        {
            Limpar();
            Cabecalho("Sistema Bancario Distribuido Nacional");
            Console.WriteLine("Utilizador inicial: admin");
            Console.WriteLine("Senha inicial: admin123");
            Console.WriteLine($"Ficheiro de dados: {dataPath}");
            Console.WriteLine();

            if (!Login())
            {
                return;
            }

            MenuPrincipal();
        }
    }

    private bool Login()
    {
        while (true)
        {
            Console.WriteLine("1 - Entrar");
            Console.WriteLine("0 - Sair");
            Console.Write("Opcao: ");
            var opcao = Console.ReadLine();

            if (opcao == "0")
            {
                return false;
            }

            if (opcao != "1")
            {
                Mensagem("Opcao invalida.");
                continue;
            }

            Console.Write("Utilizador: ");
            var nomeUsuario = Console.ReadLine() ?? string.Empty;
            Console.Write("Senha: ");
            var senha = LerSenha();

            var resultado = authService.Autenticar(nomeUsuario, senha);
            if (!resultado.Sucesso || resultado.Valor is null)
            {
                Mensagem(resultado.Mensagem);
                continue;
            }

            utilizadorAtual = resultado.Valor;
            Mensagem(resultado.Mensagem);
            return true;
        }
    }

    private void MenuPrincipal()
    {
        while (utilizadorAtual is not null)
        {
            Limpar();
            Cabecalho("Menu Principal");
            Console.WriteLine($"Sessao: {utilizadorAtual.NomeCompleto} | Perfil: {utilizadorAtual.Perfil}");
            Console.WriteLine();
            Console.WriteLine("1 - Clientes");
            Console.WriteLine("2 - Contas");
            Console.WriteLine("3 - Deposito");
            Console.WriteLine("4 - Levantamento");
            Console.WriteLine("5 - Transferencia");
            Console.WriteLine("6 - Extrato");
            Console.WriteLine("7 - Dashboard e relatorios");
            Console.WriteLine("8 - Utilizadores internos");
            Console.WriteLine("9 - Auditoria");
            Console.WriteLine("0 - Terminar sessao");
            Console.Write("Opcao: ");

            switch (Console.ReadLine())
            {
                case "1":
                    MenuClientes();
                    break;
                case "2":
                    MenuContas();
                    break;
                case "3":
                    OperacaoDeposito();
                    break;
                case "4":
                    OperacaoLevantamento();
                    break;
                case "5":
                    OperacaoTransferencia();
                    break;
                case "6":
                    MostrarExtrato();
                    break;
                case "7":
                    MostrarDashboard();
                    break;
                case "8":
                    MenuUtilizadores();
                    break;
                case "9":
                    MostrarAuditoria();
                    break;
                case "0":
                    utilizadorAtual = null;
                    return;
                default:
                    Mensagem("Opcao invalida.");
                    break;
            }
        }
    }

    private void MenuClientes()
    {
        while (true)
        {
            Limpar();
            Cabecalho("Clientes");
            Console.WriteLine("1 - Cadastrar cliente");
            Console.WriteLine("2 - Listar clientes");
            Console.WriteLine("3 - Consultar cliente por documento");
            Console.WriteLine("4 - Atualizar dados");
            Console.WriteLine("0 - Voltar");
            Console.Write("Opcao: ");

            switch (Console.ReadLine())
            {
                case "1":
                    CadastrarCliente();
                    break;
                case "2":
                    ListarClientes();
                    Pausa();
                    break;
                case "3":
                    ConsultarCliente();
                    break;
                case "4":
                    AtualizarCliente();
                    break;
                case "0":
                    return;
                default:
                    Mensagem("Opcao invalida.");
                    break;
            }
        }
    }

    private void MenuContas()
    {
        while (true)
        {
            Limpar();
            Cabecalho("Contas");
            Console.WriteLine("1 - Abrir conta");
            Console.WriteLine("2 - Listar contas");
            Console.WriteLine("0 - Voltar");
            Console.Write("Opcao: ");

            switch (Console.ReadLine())
            {
                case "1":
                    AbrirConta();
                    break;
                case "2":
                    ListarContas();
                    Pausa();
                    break;
                case "0":
                    return;
                default:
                    Mensagem("Opcao invalida.");
                    break;
            }
        }
    }

    private void MenuUtilizadores()
    {
        while (true)
        {
            Limpar();
            Cabecalho("Utilizadores internos");
            Console.WriteLine("1 - Criar utilizador");
            Console.WriteLine("2 - Listar utilizadores");
            Console.WriteLine("0 - Voltar");
            Console.Write("Opcao: ");

            switch (Console.ReadLine())
            {
                case "1":
                    CriarUtilizador();
                    break;
                case "2":
                    ListarUtilizadores();
                    Pausa();
                    break;
                case "0":
                    return;
                default:
                    Mensagem("Opcao invalida.");
                    break;
            }
        }
    }

    private void CadastrarCliente()
    {
        Limpar();
        Cabecalho("Cadastrar Cliente");
        var nome = LerObrigatorio("Nome completo: ");
        var documento = LerObrigatorio("Documento/BI: ");
        var dataNascimento = LerDataOpcional("Data nascimento (yyyy-MM-dd, opcional): ");
        Console.Write("Telefone: ");
        var telefone = Console.ReadLine() ?? string.Empty;
        Console.Write("Email: ");
        var email = Console.ReadLine() ?? string.Empty;
        Console.Write("Morada: ");
        var morada = Console.ReadLine() ?? string.Empty;

        var resultado = bancoService.CadastrarCliente(UsuarioId(), nome, documento, telefone, email, morada, dataNascimento);
        MostrarResultado(resultado);
    }

    private void AtualizarCliente()
    {
        Limpar();
        Cabecalho("Atualizar Cliente");
        ListarClientes();
        var clienteId = LerInteiro("ID do cliente: ");
        var nome = LerObrigatorio("Novo nome completo: ");
        Console.Write("Telefone: ");
        var telefone = Console.ReadLine() ?? string.Empty;
        Console.Write("Email: ");
        var email = Console.ReadLine() ?? string.Empty;
        Console.Write("Morada: ");
        var morada = Console.ReadLine() ?? string.Empty;

        var resultado = bancoService.AtualizarCliente(UsuarioId(), clienteId, nome, telefone, email, morada);
        MostrarResultado(resultado);
    }

    private void ConsultarCliente()
    {
        Limpar();
        Cabecalho("Consultar Cliente");
        var documento = LerObrigatorio("Documento/BI: ");
        var cliente = bancoService.ListarClientes()
            .FirstOrDefault(item => string.Equals(item.Documento, documento, StringComparison.OrdinalIgnoreCase));

        if (cliente is null)
        {
            Mensagem("Cliente nao encontrado.");
            return;
        }

        MostrarCliente(cliente);
        Console.WriteLine();
        Console.WriteLine("Contas do cliente:");
        foreach (var conta in bancoService.ListarContas().Where(conta => conta.ClienteId == cliente.Id))
        {
            MostrarConta(conta);
        }

        Pausa();
    }

    private void AbrirConta()
    {
        Limpar();
        Cabecalho("Abrir Conta");
        ListarClientes();
        var clienteId = LerInteiro("ID do cliente: ");
        Console.WriteLine();
        ListarAgencias();
        var agenciaId = LerInteiro("ID da agencia: ");
        var tipo = LerTipoConta();
        var saldoInicial = LerDecimal("Saldo inicial: ");

        var resultado = bancoService.AbrirConta(UsuarioId(), clienteId, agenciaId, tipo, saldoInicial);
        if (resultado.Sucesso && resultado.Valor is not null)
        {
            Console.WriteLine(resultado.Mensagem);
            MostrarConta(resultado.Valor);
            Pausa();
            return;
        }

        MostrarResultado(resultado);
    }

    private void OperacaoDeposito()
    {
        Limpar();
        Cabecalho("Deposito");
        var numero = LerObrigatorio("Numero da conta: ");
        var valor = LerDecimal("Valor: ");
        Console.Write("Descricao: ");
        var descricao = Console.ReadLine() ?? string.Empty;

        var resultado = bancoService.Depositar(UsuarioId(), numero, valor, descricao);
        MostrarResultado(resultado);
    }

    private void OperacaoLevantamento()
    {
        Limpar();
        Cabecalho("Levantamento");
        var numero = LerObrigatorio("Numero da conta: ");
        var valor = LerDecimal("Valor: ");
        Console.Write("Descricao: ");
        var descricao = Console.ReadLine() ?? string.Empty;

        var resultado = bancoService.Levantar(UsuarioId(), numero, valor, descricao);
        MostrarResultado(resultado);
    }

    private void OperacaoTransferencia()
    {
        Limpar();
        Cabecalho("Transferencia");
        var origem = LerObrigatorio("Conta origem: ");
        var destino = LerObrigatorio("Conta destino: ");
        var valor = LerDecimal("Valor: ");
        Console.Write("Descricao: ");
        var descricao = Console.ReadLine() ?? string.Empty;

        var resultado = bancoService.Transferir(UsuarioId(), origem, destino, valor, descricao);
        MostrarResultado(resultado);
    }

    private void MostrarExtrato()
    {
        Limpar();
        Cabecalho("Extrato");
        var numero = LerObrigatorio("Numero da conta: ");
        var transacoes = bancoService.Extrato(numero);

        if (transacoes.Count == 0)
        {
            Console.WriteLine("Sem movimentos para esta conta ou conta nao encontrada.");
            Pausa();
            return;
        }

        foreach (var transacao in transacoes)
        {
            Console.WriteLine($"{transacao.CriadoEm:yyyy-MM-dd HH:mm} | {transacao.Tipo,-25} | {transacao.Valor,12:N2} | Saldo: {transacao.SaldoApos,12:N2} | Ref: {transacao.Referencia}");
            Console.WriteLine($"  {transacao.Descricao}");
        }

        Pausa();
    }

    private void MostrarDashboard()
    {
        Limpar();
        Cabecalho("Dashboard");
        var resumo = bancoService.ObterDashboard();
        Console.WriteLine($"Total clientes:     {resumo.TotalClientes}");
        Console.WriteLine($"Total contas:       {resumo.TotalContas}");
        Console.WriteLine($"Total agencias:     {resumo.TotalAgencias}");
        Console.WriteLine($"Saldo global:       {resumo.SaldoGlobal:N2} AOA");
        Console.WriteLine($"Total transacoes:   {resumo.TotalTransacoes}");
        Console.WriteLine($"Volume transacoes:  {resumo.VolumeTransacoes:N2} AOA");
        Pausa();
    }

    private void CriarUtilizador()
    {
        Limpar();
        Cabecalho("Criar Utilizador");
        var nome = LerObrigatorio("Nome completo: ");
        var usuario = LerObrigatorio("Nome de usuario: ");
        Console.Write("Senha: ");
        var senha = LerSenha();
        var perfil = LerPerfil();
        ListarAgencias();
        Console.Write("ID da agencia (vazio para sem agencia): ");
        var agenciaTexto = Console.ReadLine();
        int? agenciaId = int.TryParse(agenciaTexto, out var id) ? id : null;

        var resultado = bancoService.CriarUtilizador(UsuarioId(), nome, usuario, senha, perfil, agenciaId);
        MostrarResultado(resultado);
    }

    private void MostrarAuditoria()
    {
        Limpar();
        Cabecalho("Auditoria - ultimos 50 registos");
        foreach (var item in bancoService.ListarAuditoria())
        {
            Console.WriteLine($"{item.CriadoEm:yyyy-MM-dd HH:mm} | User:{item.UtilizadorId} | {item.Acao,-15} | {item.Entidade,-20} | {item.Detalhes}");
        }

        Pausa();
    }

    private void ListarClientes()
    {
        var clientes = bancoService.ListarClientes();
        if (clientes.Count == 0)
        {
            Console.WriteLine("Nenhum cliente cadastrado.");
            return;
        }

        foreach (var cliente in clientes)
        {
            MostrarCliente(cliente);
        }
    }

    private void ListarContas()
    {
        var contas = bancoService.ListarContas();
        if (contas.Count == 0)
        {
            Console.WriteLine("Nenhuma conta aberta.");
            return;
        }

        foreach (var conta in contas)
        {
            MostrarConta(conta);
        }
    }

    private void ListarAgencias()
    {
        foreach (var agencia in bancoService.ListarAgencias())
        {
            Console.WriteLine($"{agencia.Id,2} | {agencia.Codigo,-4} | {agencia.Nome,-25} | {agencia.Provincia}");
        }
    }

    private void ListarUtilizadores()
    {
        foreach (var utilizador in bancoService.ListarUtilizadores())
        {
            Console.WriteLine($"{utilizador.Id,2} | {utilizador.NomeUsuario,-15} | {utilizador.NomeCompleto,-30} | {utilizador.Perfil,-15} | Ativo: {utilizador.Ativo}");
        }
    }

    private static void MostrarCliente(Cliente cliente)
    {
        Console.WriteLine($"{cliente.Id,2} | {cliente.NomeCompleto,-30} | Doc: {cliente.Documento,-15} | Tel: {cliente.Telefone}");
    }

    private void MostrarConta(Conta conta)
    {
        var cliente = bancoService.ListarClientes().FirstOrDefault(item => item.Id == conta.ClienteId);
        var agencia = bancoService.ListarAgencias().FirstOrDefault(item => item.Id == conta.AgenciaId);
        Console.WriteLine($"{conta.Id,2} | {conta.Numero,-14} | {conta.Tipo,-8} | {conta.Estado,-10} | {conta.Saldo,12:N2} AOA | {cliente?.NomeCompleto ?? "Cliente"} | {agencia?.Nome ?? "Agencia"}");
    }

    private static void MostrarResultado(Resultado resultado)
    {
        Mensagem(resultado.Mensagem);
    }

    private int UsuarioId() => utilizadorAtual?.Id ?? 0;

    private static TipoConta LerTipoConta()
    {
        while (true)
        {
            Console.WriteLine("Tipo de conta:");
            Console.WriteLine("1 - Corrente");
            Console.WriteLine("2 - Poupanca");
            Console.Write("Opcao: ");
            var opcao = Console.ReadLine();
            if (opcao == "1")
            {
                return TipoConta.Corrente;
            }

            if (opcao == "2")
            {
                return TipoConta.Poupanca;
            }

            Console.WriteLine("Opcao invalida.");
        }
    }

    private static PerfilUtilizador LerPerfil()
    {
        while (true)
        {
            Console.WriteLine("Perfil:");
            Console.WriteLine("1 - Operador");
            Console.WriteLine("2 - Gerente");
            Console.WriteLine("3 - Auditor");
            Console.WriteLine("4 - Administrador");
            Console.Write("Opcao: ");
            var opcao = Console.ReadLine();
            if (int.TryParse(opcao, out var valor) && Enum.IsDefined(typeof(PerfilUtilizador), valor))
            {
                return (PerfilUtilizador)valor;
            }

            Console.WriteLine("Opcao invalida.");
        }
    }

    private static DateOnly? LerDataOpcional(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            var valor = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(valor))
            {
                return null;
            }

            if (DateOnly.TryParseExact(valor, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var data))
            {
                return data;
            }

            Console.WriteLine("Data invalida. Use o formato yyyy-MM-dd.");
        }
    }

    private static int LerInteiro(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            if (int.TryParse(Console.ReadLine(), out var valor))
            {
                return valor;
            }

            Console.WriteLine("Informe um numero inteiro valido.");
        }
    }

    private static decimal LerDecimal(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            var texto = Console.ReadLine();
            if (decimal.TryParse(texto, NumberStyles.Number, CultureInfo.CurrentCulture, out var valor) ||
                decimal.TryParse(texto, NumberStyles.Number, CultureInfo.InvariantCulture, out valor))
            {
                return valor;
            }

            Console.WriteLine("Informe um valor monetario valido.");
        }
    }

    private static string LerObrigatorio(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            var valor = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(valor))
            {
                return valor.Trim();
            }

            Console.WriteLine("Campo obrigatorio.");
        }
    }

    private static string LerSenha()
    {
        var senha = new StringBuilder();
        while (true)
        {
            var tecla = Console.ReadKey(intercept: true);
            if (tecla.Key == ConsoleKey.Enter)
            {
                Console.WriteLine();
                return senha.ToString();
            }

            if (tecla.Key == ConsoleKey.Backspace)
            {
                if (senha.Length > 0)
                {
                    senha.Length--;
                    Console.Write("\b \b");
                }

                continue;
            }

            if (!char.IsControl(tecla.KeyChar))
            {
                senha.Append(tecla.KeyChar);
                Console.Write("*");
            }
        }
    }

    private static void Cabecalho(string titulo)
    {
        Console.WriteLine("==============================================");
        Console.WriteLine(titulo);
        Console.WriteLine("==============================================");
    }

    private static void Limpar()
    {
        try
        {
            Console.Clear();
        }
        catch (IOException)
        {
            // Saida redirecionada: continuar sem limpar.
        }
    }

    private static void Mensagem(string mensagem)
    {
        Console.WriteLine();
        Console.WriteLine(mensagem);
        Pausa();
    }

    private static void Pausa()
    {
        Console.WriteLine();
        Console.Write("Prima ENTER para continuar...");
        Console.ReadLine();
    }
}
