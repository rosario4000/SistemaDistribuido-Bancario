using Banco.Core.Entities;

namespace Banco.Application.Interfaces;

public interface IBancoRepository
{
    IReadOnlyList<Agencia> ListarAgencias();
    Agencia? ObterAgencia(int id);

    IReadOnlyList<Cliente> ListarClientes();
    Cliente? ObterCliente(int id);
    Cliente? ObterClientePorDocumento(string documento);
    void GuardarCliente(Cliente cliente);

    IReadOnlyList<Conta> ListarContas();
    Conta? ObterConta(int id);
    Conta? ObterContaPorNumero(string numero);
    void GuardarConta(Conta conta);

    IReadOnlyList<UtilizadorInterno> ListarUtilizadores();
    UtilizadorInterno? ObterUtilizador(int id);
    UtilizadorInterno? ObterUtilizadorPorNome(string nomeUsuario);
    void GuardarUtilizador(UtilizadorInterno utilizador);

    IReadOnlyList<Transacao> ListarTransacoes();
    void GuardarTransacao(Transacao transacao);

    IReadOnlyList<Transferencia> ListarTransferencias();
    void GuardarTransferencia(Transferencia transferencia);

    IReadOnlyList<Auditoria> ListarAuditoria();
    void GuardarAuditoria(Auditoria auditoria);

    int ProximoId(string entidade);
    string ProximoNumeroConta(int agenciaId);
}
