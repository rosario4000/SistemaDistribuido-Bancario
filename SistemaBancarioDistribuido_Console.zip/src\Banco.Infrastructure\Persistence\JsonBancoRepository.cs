using System.Text.Json;
using Banco.Application.Interfaces;
using Banco.Application.Security;
using Banco.Core.Entities;
using Banco.Core.Enums;

namespace Banco.Infrastructure.Persistence;

public sealed class JsonBancoRepository : IBancoRepository
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true
    };

    private readonly object sync = new();
    private readonly string dataPath;
    private BancoDataFile data;

    public JsonBancoRepository(string dataPath)
    {
        this.dataPath = dataPath;
        data = Carregar();
        GarantirDadosIniciais();
        Salvar();
    }

    public IReadOnlyList<Agencia> ListarAgencias()
    {
        lock (sync)
        {
            return data.Agencias.ToList();
        }
    }

    public Agencia? ObterAgencia(int id)
    {
        lock (sync)
        {
            return data.Agencias.FirstOrDefault(agencia => agencia.Id == id);
        }
    }

    public IReadOnlyList<Cliente> ListarClientes()
    {
        lock (sync)
        {
            return data.Clientes.ToList();
        }
    }

    public Cliente? ObterCliente(int id)
    {
        lock (sync)
        {
            return data.Clientes.FirstOrDefault(cliente => cliente.Id == id);
        }
    }

    public Cliente? ObterClientePorDocumento(string documento)
    {
        lock (sync)
        {
            return data.Clientes.FirstOrDefault(cliente => string.Equals(cliente.Documento, documento.Trim(), StringComparison.OrdinalIgnoreCase));
        }
    }

    public void GuardarCliente(Cliente cliente)
    {
        lock (sync)
        {
            Upsert(data.Clientes, cliente, item => item.Id);
            Salvar();
        }
    }

    public IReadOnlyList<Conta> ListarContas()
    {
        lock (sync)
        {
            return data.Contas.ToList();
        }
    }

    public Conta? ObterConta(int id)
    {
        lock (sync)
        {
            return data.Contas.FirstOrDefault(conta => conta.Id == id);
        }
    }

    public Conta? ObterContaPorNumero(string numero)
    {
        lock (sync)
        {
            return data.Contas.FirstOrDefault(conta => string.Equals(conta.Numero, numero.Trim(), StringComparison.OrdinalIgnoreCase));
        }
    }

    public void GuardarConta(Conta conta)
    {
        lock (sync)
        {
            Upsert(data.Contas, conta, item => item.Id);
            Salvar();
        }
    }

    public IReadOnlyList<UtilizadorInterno> ListarUtilizadores()
    {
        lock (sync)
        {
            return data.Utilizadores.ToList();
        }
    }

    public UtilizadorInterno? ObterUtilizador(int id)
    {
        lock (sync)
        {
            return data.Utilizadores.FirstOrDefault(utilizador => utilizador.Id == id);
        }
    }

    public UtilizadorInterno? ObterUtilizadorPorNome(string nomeUsuario)
    {
        lock (sync)
        {
            return data.Utilizadores.FirstOrDefault(utilizador => string.Equals(utilizador.NomeUsuario, nomeUsuario.Trim(), StringComparison.OrdinalIgnoreCase));
        }
    }

    public void GuardarUtilizador(UtilizadorInterno utilizador)
    {
        lock (sync)
        {
            Upsert(data.Utilizadores, utilizador, item => item.Id);
            Salvar();
        }
    }

    public IReadOnlyList<Transacao> ListarTransacoes()
    {
        lock (sync)
        {
            return data.Transacoes.ToList();
        }
    }

    public void GuardarTransacao(Transacao transacao)
    {
        lock (sync)
        {
            Upsert(data.Transacoes, transacao, item => item.Id);
            Salvar();
        }
    }

    public IReadOnlyList<Transferencia> ListarTransferencias()
    {
        lock (sync)
        {
            return data.Transferencias.ToList();
        }
    }

    public void GuardarTransferencia(Transferencia transferencia)
    {
        lock (sync)
        {
            Upsert(data.Transferencias, transferencia, item => item.Id);
            Salvar();
        }
    }

    public IReadOnlyList<Auditoria> ListarAuditoria()
    {
        lock (sync)
        {
            return data.Auditoria.ToList();
        }
    }

    public void GuardarAuditoria(Auditoria auditoria)
    {
        lock (sync)
        {
            Upsert(data.Auditoria, auditoria, item => item.Id);
            Salvar();
        }
    }

    public int ProximoId(string entidade)
    {
        lock (sync)
        {
            if (!data.Sequencias.TryGetValue(entidade, out var atual))
            {
                atual = MaiorId(entidade);
            }

            atual++;
            data.Sequencias[entidade] = atual;
            Salvar();
            return atual;
        }
    }

    public string ProximoNumeroConta(int agenciaId)
    {
        lock (sync)
        {
            var agencia = data.Agencias.FirstOrDefault(item => item.Id == agenciaId);
            var codigoAgencia = agencia?.Codigo ?? agenciaId.ToString("000");
            var chave = $"ContaNumero:{agenciaId}";
            data.Sequencias.TryGetValue(chave, out var atual);

            string numero;
            do
            {
                atual++;
                numero = $"{codigoAgencia}{DateTime.UtcNow:yy}{atual:000000}";
            }
            while (data.Contas.Any(conta => string.Equals(conta.Numero, numero, StringComparison.OrdinalIgnoreCase)));

            data.Sequencias[chave] = atual;
            Salvar();
            return numero;
        }
    }

    private BancoDataFile Carregar()
    {
        if (!File.Exists(dataPath))
        {
            return new BancoDataFile();
        }

        var json = File.ReadAllText(dataPath);
        if (string.IsNullOrWhiteSpace(json))
        {
            return new BancoDataFile();
        }

        return JsonSerializer.Deserialize<BancoDataFile>(json, JsonOptions) ?? new BancoDataFile();
    }

    private void Salvar()
    {
        var directory = Path.GetDirectoryName(dataPath);
        if (!string.IsNullOrWhiteSpace(directory))
        {
            Directory.CreateDirectory(directory);
        }

        var json = JsonSerializer.Serialize(data, JsonOptions);
        File.WriteAllText(dataPath, json);
    }

    private void GarantirDadosIniciais()
    {
        if (data.Agencias.Count == 0)
        {
            data.Agencias.AddRange(
                new Agencia { Id = 1, Codigo = "LAD", Nome = "Agencia Luanda", Provincia = "Luanda", Endereco = "Luanda" },
                new Agencia { Id = 2, Codigo = "BGU", Nome = "Agencia Benguela", Provincia = "Benguela", Endereco = "Benguela" },
                new Agencia { Id = 3, Codigo = "CAB", Nome = "Agencia Cabinda", Provincia = "Cabinda", Endereco = "Cabinda" },
                new Agencia { Id = 4, Codigo = "UIG", Nome = "Sede Central Uige", Provincia = "Uige", Endereco = "Uige" });
        }

        if (data.Utilizadores.Count == 0)
        {
            var (hash, salt) = PasswordHasher.CriarHash("admin123");
            data.Utilizadores.Add(new UtilizadorInterno
            {
                Id = 1,
                NomeCompleto = "Administrador Geral",
                NomeUsuario = "admin",
                Perfil = PerfilUtilizador.Administrador,
                AgenciaId = 4,
                SenhaHash = hash,
                SenhaSalt = salt,
                Ativo = true,
                CriadoEm = DateTime.UtcNow
            });
        }

        AtualizarSequencia(nameof(Agencia), data.Agencias.Select(agencia => agencia.Id).DefaultIfEmpty().Max());
        AtualizarSequencia(nameof(UtilizadorInterno), data.Utilizadores.Select(utilizador => utilizador.Id).DefaultIfEmpty().Max());
        AtualizarSequencia(nameof(Cliente), data.Clientes.Select(cliente => cliente.Id).DefaultIfEmpty().Max());
        AtualizarSequencia(nameof(Conta), data.Contas.Select(conta => conta.Id).DefaultIfEmpty().Max());
        AtualizarSequencia(nameof(Transacao), data.Transacoes.Select(transacao => transacao.Id).DefaultIfEmpty().Max());
        AtualizarSequencia(nameof(Transferencia), data.Transferencias.Select(transferencia => transferencia.Id).DefaultIfEmpty().Max());
        AtualizarSequencia(nameof(Auditoria), data.Auditoria.Select(auditoria => auditoria.Id).DefaultIfEmpty().Max());
    }

    private void AtualizarSequencia(string entidade, int maiorId)
    {
        if (!data.Sequencias.TryGetValue(entidade, out var atual) || atual < maiorId)
        {
            data.Sequencias[entidade] = maiorId;
        }
    }

    private int MaiorId(string entidade)
    {
        return entidade switch
        {
            nameof(Agencia) => data.Agencias.Select(item => item.Id).DefaultIfEmpty().Max(),
            nameof(Cliente) => data.Clientes.Select(item => item.Id).DefaultIfEmpty().Max(),
            nameof(Conta) => data.Contas.Select(item => item.Id).DefaultIfEmpty().Max(),
            nameof(UtilizadorInterno) => data.Utilizadores.Select(item => item.Id).DefaultIfEmpty().Max(),
            nameof(Transacao) => data.Transacoes.Select(item => item.Id).DefaultIfEmpty().Max(),
            nameof(Transferencia) => data.Transferencias.Select(item => item.Id).DefaultIfEmpty().Max(),
            nameof(Auditoria) => data.Auditoria.Select(item => item.Id).DefaultIfEmpty().Max(),
            _ => 0
        };
    }

    private static void Upsert<T>(List<T> items, T item, Func<T, int> obterId)
    {
        var index = items.FindIndex(existing => obterId(existing) == obterId(item));
        if (index >= 0)
        {
            items[index] = item;
            return;
        }

        items.Add(item);
    }
}
