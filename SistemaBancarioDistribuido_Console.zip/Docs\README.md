# Sistema Bancario Distribuido - Console

Projeto baseado no guiao enviado: sistema bancario nacional com agencias em Luanda, Benguela, Cabinda e sede central no Uige.

## Objetivo

Entregar uma aplicacao C# em modo console, sem formularios, com as funcionalidades principais do guiao:

- Login de utilizadores internos
- Cadastro, consulta e atualizacao de clientes
- Abertura de conta corrente ou poupanca
- Deposito, levantamento e transferencia entre contas
- Extrato de movimentos
- Dashboard com total de clientes, contas e volume de transacoes
- Auditoria das operacoes

## Estrutura

```text
SistemaDistriubuido/
|-- Database/                 scripts SQL Server
|-- Docs/                     documentacao do projeto
|-- src/
|   |-- Banco.Core/           entidades e enums do dominio
|   |-- Banco.Application/    regras de negocio e contratos
|   |-- Banco.Infrastructure/ persistencia JSON local
|   `-- Banco.ConsoleApp/     interface de terminal
`-- Tests/Banco.Tests/        testes simples sem dependencias externas
```

## Como executar

```powershell
dotnet run --project src\Banco.ConsoleApp
```

Credenciais iniciais:

```text
Utilizador: admin
Senha: admin123
```

A aplicacao grava dados em `Data/banco-data.json`. Para usar outro caminho, defina a variavel `BANCO_DATA_PATH`.

## Como testar

```powershell
dotnet run --project Tests\Banco.Tests
```

## SQL Server

Os scripts em `Database/` criam a base de dados central remota prevista no guiao:

1. `01_schema.sql` cria tabelas, chaves, constraints e indices.
2. `02_seed.sql` cria agencias iniciais e o utilizador `admin`.
3. `03_procedures.sql` cria procedures para deposito, levantamento e transferencia com transacao SQL.

Para uma entrega academica, pode demonstrar a aplicacao de console com JSON e apresentar o SQL Server como a camada central remota preparada para deploy.
