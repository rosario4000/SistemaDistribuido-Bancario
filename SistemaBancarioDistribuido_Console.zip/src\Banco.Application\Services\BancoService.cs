using Banco.Application.Common;
using Banco.Application.Interfaces;
using Banco.Application.Security;
using Banco.Core.Entities;
using Banco.Core.Enums;

namespace Banco.Application.Services;

public sealed class BancoService
{
    private readonly IBancoRepository repository;

    public BancoService(IBancoRepository repository)
    {
        this.repository = repository;
    }

    public Resultado<Cliente> CadastrarCliente(
        int utilizadorId,
        string nomeCompleto,
        string documento,
        string telefone,
        string email,
        string morada,
        DateOnly? dataNascimento = null)
    {
        if (string.IsNullOrWhiteSpace(nomeCompleto) || string.IsNullOrWhiteSpace(documento))
        {
            return Resultado<Cliente>.Falha("Nome completo e documento sao obrigatorios.");
        }

        if (repository.ObterClientePorDocumento(documento.Trim()) is not null)
        {
            return Resultado<Cliente>.Falha("Ja existe um cliente com este documento.");
        }

        var cliente = new Cliente
        {
            Id = repository.ProximoId(nameof(Cliente)),
            NomeCompleto = nomeCompleto.Trim(),
            Documento = documento.Trim(),
            Telefone = telefone.Trim(),
            Email = email.Trim(),
            Morada = morada.Trim(),
            DataNascimento = dataNascimento,
            CriadoEm = DateTime.UtcNow
        };

        repository.GuardarCliente(cliente);
        Auditar(utilizadorId, "CRIAR", nameof(Cliente), cliente.Id, $"Cliente {cliente.Documento} cadastrado.");

        return Resultado<Cliente>.Ok(cliente, "Cliente cadastrado com sucesso.");
    }

    public Resultado AtualizarCliente(
        int utilizadorId,
        int clienteId,
        string nomeCompleto,
        string telefone,
        string email,
        string morada)
    {
        var cliente = repository.ObterCliente(clienteId);
        if (cliente is null)
        {
            return Resultado.Falha("Cliente nao encontrado.");
        }

        if (string.IsNullOrWhiteSpace(nomeCompleto))
        {
            return Resultado.Falha("Nome completo e obrigatorio.");
        }

        cliente.NomeCompleto = nomeCompleto.Trim();
        cliente.Telefone = telefone.Trim();
        cliente.Email = email.Trim();
        cliente.Morada = morada.Trim();
        cliente.AtualizadoEm = DateTime.UtcNow;

        repository.GuardarCliente(cliente);
        Auditar(utilizadorId, "ATUALIZAR", nameof(Cliente), cliente.Id, $"Dados do cliente {cliente.Documento} atualizados.");

        return Resultado.Ok("Cliente atualizado com sucesso.");
    }

    public Resultado<Conta> AbrirConta(int utilizadorId, int clienteId, int agenciaId, TipoConta tipo, decimal saldoInicial)
    {
        if (saldoInicial < 0)
        {
            return Resultado<Conta>.Falha("Saldo inicial nao pode ser negativo.");
        }

        var cliente = repository.ObterCliente(clienteId);
        if (cliente is null)
        {
            return Resultado<Conta>.Falha("Cliente nao encontrado.");
        }

        var agencia = repository.ObterAgencia(agenciaId);
        if (agencia is null || !agencia.Ativa)
        {
            return Resultado<Conta>.Falha("Agencia invalida ou inativa.");
        }

        var conta = new Conta
        {
            Id = repository.ProximoId(nameof(Conta)),
            Numero = repository.ProximoNumeroConta(agenciaId),
            ClienteId = clienteId,
            AgenciaId = agenciaId,
            Tipo = tipo,
            Estado = EstadoConta.Ativa,
            Saldo = saldoInicial,
            CriadoEm = DateTime.UtcNow
        };

        repository.GuardarConta(conta);

        if (saldoInicial > 0)
        {
            RegistrarTransacao(conta, utilizadorId, TipoTransacao.Abertura, saldoInicial, "Saldo inicial de abertura", NovaReferencia("ABR"));
        }

        Auditar(utilizadorId, "CRIAR", nameof(Conta), conta.Id, $"Conta {conta.Numero} aberta para cliente {cliente.Documento}.");
        return Resultado<Conta>.Ok(conta, $"Conta {conta.Numero} aberta com sucesso.");
    }

    public Resultado<Transacao> Depositar(int utilizadorId, string numeroConta, decimal valor, string descricao)
    {
        if (valor <= 0)
        {
            return Resultado<Transacao>.Falha("Valor do deposito deve ser positivo.");
        }

        var conta = ObterContaOperacional(numeroConta);
        if (conta is null)
        {
            return Resultado<Transacao>.Falha("Conta nao encontrada ou indisponivel.");
        }

        conta.Saldo += valor;
        repository.GuardarConta(conta);

        var transacao = RegistrarTransacao(conta, utilizadorId, TipoTransacao.Deposito, valor, descricao, NovaReferencia("DEP"));
        Auditar(utilizadorId, "DEPOSITO", nameof(Conta), conta.Id, $"Deposito de {valor:N2} na conta {conta.Numero}.");

        return Resultado<Transacao>.Ok(transacao, "Deposito realizado com sucesso.");
    }

    public Resultado<Transacao> Levantar(int utilizadorId, string numeroConta, decimal valor, string descricao)
    {
        if (valor <= 0)
        {
            return Resultado<Transacao>.Falha("Valor do levantamento deve ser positivo.");
        }

        var conta = ObterContaOperacional(numeroConta);
        if (conta is null)
        {
            return Resultado<Transacao>.Falha("Conta nao encontrada ou indisponivel.");
        }

        if (conta.Saldo < valor)
        {
            return Resultado<Transacao>.Falha("Saldo insuficiente.");
        }

        conta.Saldo -= valor;
        repository.GuardarConta(conta);

        var transacao = RegistrarTransacao(conta, utilizadorId, TipoTransacao.Levantamento, valor, descricao, NovaReferencia("LEV"));
        Auditar(utilizadorId, "LEVANTAMENTO", nameof(Conta), conta.Id, $"Levantamento de {valor:N2} na conta {conta.Numero}.");

        return Resultado<Transacao>.Ok(transacao, "Levantamento realizado com sucesso.");
    }

    public Resultado<Transferencia> Transferir(int utilizadorId, string origem, string destino, decimal valor, string descricao)
    {
        if (valor <= 0)
        {
            return Resultado<Transferencia>.Falha("Valor da transferencia deve ser positivo.");
        }

        var contaOrigem = ObterContaOperacional(origem);
        var contaDestino = ObterContaOperacional(destino);
        if (contaOrigem is null || contaDestino is null)
        {
            return Resultado<Transferencia>.Falha("Conta de origem ou destino nao encontrada.");
        }

        if (contaOrigem.Id == contaDestino.Id)
        {
            return Resultado<Transferencia>.Falha("A conta de origem deve ser diferente da conta de destino.");
        }

        if (contaOrigem.Saldo < valor)
        {
            return Resultado<Transferencia>.Falha("Saldo insuficiente para transferencia.");
        }

        var referencia = NovaReferencia("TRF");
        contaOrigem.Saldo -= valor;
        contaDestino.Saldo += valor;

        repository.GuardarConta(contaOrigem);
        repository.GuardarConta(contaDestino);

        var transferencia = new Transferencia
        {
            Id = repository.ProximoId(nameof(Transferencia)),
            ContaOrigemId = contaOrigem.Id,
            ContaDestinoId = contaDestino.Id,
            UtilizadorId = utilizadorId,
            Valor = valor,
            Referencia = referencia,
            CriadoEm = DateTime.UtcNow
        };

        repository.GuardarTransferencia(transferencia);
        RegistrarTransacao(contaOrigem, utilizadorId, TipoTransacao.TransferenciaEnviada, valor, descricao, referencia);
        RegistrarTransacao(contaDestino, utilizadorId, TipoTransacao.TransferenciaRecebida, valor, descricao, referencia);
        Auditar(utilizadorId, "TRANSFERENCIA", nameof(Transferencia), transferencia.Id, $"Transferencia {referencia} de {origem} para {destino}.");

        return Resultado<Transferencia>.Ok(transferencia, $"Transferencia {referencia} realizada com sucesso.");
    }

    public IReadOnlyList<Transacao> Extrato(string numeroConta)
    {
        var conta = repository.ObterContaPorNumero(numeroConta.Trim());
        if (conta is null)
        {
            return Array.Empty<Transacao>();
        }

        return repository
            .ListarTransacoes()
            .Where(transacao => transacao.ContaId == conta.Id)
            .OrderByDescending(transacao => transacao.CriadoEm)
            .ToList();
    }

    public DashboardResumo ObterDashboard()
    {
        var contas = repository.ListarContas();
        var transacoes = repository.ListarTransacoes();

        return new DashboardResumo
        {
            TotalClientes = repository.ListarClientes().Count,
            TotalContas = contas.Count,
            TotalAgencias = repository.ListarAgencias().Count(agencia => agencia.Ativa),
            SaldoGlobal = contas.Where(conta => conta.Estado == EstadoConta.Ativa).Sum(conta => conta.Saldo),
            TotalTransacoes = transacoes.Count,
            VolumeTransacoes = transacoes
                .Where(transacao => transacao.Tipo != TipoTransacao.Abertura)
                .Sum(transacao => transacao.Valor)
        };
    }

    public Resultado<UtilizadorInterno> CriarUtilizador(
        int utilizadorCriadorId,
        string nomeCompleto,
        string nomeUsuario,
        string senha,
        PerfilUtilizador perfil,
        int? agenciaId)
    {
        var criador = repository.ObterUtilizador(utilizadorCriadorId);
        if (criador is null || criador.Perfil is not (PerfilUtilizador.Administrador or PerfilUtilizador.Gerente))
        {
            return Resultado<UtilizadorInterno>.Falha("Apenas administradores ou gerentes podem criar utilizadores.");
        }

        if (string.IsNullOrWhiteSpace(nomeCompleto) || string.IsNullOrWhiteSpace(nomeUsuario) || senha.Length < 6)
        {
            return Resultado<UtilizadorInterno>.Falha("Nome, usuario e senha com minimo de 6 caracteres sao obrigatorios.");
        }

        if (repository.ObterUtilizadorPorNome(nomeUsuario.Trim()) is not null)
        {
            return Resultado<UtilizadorInterno>.Falha("Ja existe um utilizador com este nome de usuario.");
        }

        if (agenciaId.HasValue && repository.ObterAgencia(agenciaId.Value) is null)
        {
            return Resultado<UtilizadorInterno>.Falha("Agencia informada nao existe.");
        }

        var (hash, salt) = PasswordHasher.CriarHash(senha);
        var utilizador = new UtilizadorInterno
        {
            Id = repository.ProximoId(nameof(UtilizadorInterno)),
            NomeCompleto = nomeCompleto.Trim(),
            NomeUsuario = nomeUsuario.Trim(),
            Perfil = perfil,
            AgenciaId = agenciaId,
            SenhaHash = hash,
            SenhaSalt = salt,
            Ativo = true,
            CriadoEm = DateTime.UtcNow
        };

        repository.GuardarUtilizador(utilizador);
        Auditar(utilizadorCriadorId, "CRIAR", nameof(UtilizadorInterno), utilizador.Id, $"Utilizador {utilizador.NomeUsuario} criado.");

        return Resultado<UtilizadorInterno>.Ok(utilizador, "Utilizador criado com sucesso.");
    }

    public IReadOnlyList<Cliente> ListarClientes() => repository.ListarClientes().OrderBy(cliente => cliente.NomeCompleto).ToList();
    public IReadOnlyList<Conta> ListarContas() => repository.ListarContas().OrderBy(conta => conta.Numero).ToList();
    public IReadOnlyList<Agencia> ListarAgencias() => repository.ListarAgencias().OrderBy(agencia => agencia.Nome).ToList();
    public IReadOnlyList<UtilizadorInterno> ListarUtilizadores() => repository.ListarUtilizadores().OrderBy(utilizador => utilizador.NomeUsuario).ToList();
    public IReadOnlyList<Auditoria> ListarAuditoria() => repository.ListarAuditoria().OrderByDescending(auditoria => auditoria.CriadoEm).Take(50).ToList();

    private Conta? ObterContaOperacional(string numeroConta)
    {
        var conta = repository.ObterContaPorNumero(numeroConta.Trim());
        return conta is { Estado: EstadoConta.Ativa } ? conta : null;
    }

    private Transacao RegistrarTransacao(
        Conta conta,
        int utilizadorId,
        TipoTransacao tipo,
        decimal valor,
        string descricao,
        string referencia)
    {
        var transacao = new Transacao
        {
            Id = repository.ProximoId(nameof(Transacao)),
            ContaId = conta.Id,
            AgenciaId = conta.AgenciaId,
            UtilizadorId = utilizadorId,
            Tipo = tipo,
            Valor = valor,
            SaldoApos = conta.Saldo,
            Descricao = string.IsNullOrWhiteSpace(descricao) ? tipo.ToString() : descricao.Trim(),
            Referencia = referencia,
            CriadoEm = DateTime.UtcNow
        };

        repository.GuardarTransacao(transacao);
        return transacao;
    }

    private void Auditar(int utilizadorId, string acao, string entidade, int? entidadeId, string detalhes)
    {
        var utilizador = repository.ObterUtilizador(utilizadorId);
        repository.GuardarAuditoria(new Auditoria
        {
            Id = repository.ProximoId(nameof(Auditoria)),
            UtilizadorId = utilizadorId,
            AgenciaId = utilizador?.AgenciaId,
            Acao = acao,
            Entidade = entidade,
            EntidadeId = entidadeId,
            Detalhes = detalhes,
            CriadoEm = DateTime.UtcNow
        });
    }

    private static string NovaReferencia(string prefixo) => $"{prefixo}-{DateTime.UtcNow:yyyyMMddHHmmssfff}-{Random.Shared.Next(100, 999)}";
}
