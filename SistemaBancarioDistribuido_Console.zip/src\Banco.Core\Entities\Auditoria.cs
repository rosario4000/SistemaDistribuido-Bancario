namespace Banco.Core.Entities;

public sealed class Auditoria
{
    public int Id { get; set; }
    public int? UtilizadorId { get; set; }
    public int? AgenciaId { get; set; }
    public string Acao { get; set; } = string.Empty;
    public string Entidade { get; set; } = string.Empty;
    public int? EntidadeId { get; set; }
    public string Detalhes { get; set; } = string.Empty;
    public DateTime CriadoEm { get; set; } = DateTime.UtcNow;
}
