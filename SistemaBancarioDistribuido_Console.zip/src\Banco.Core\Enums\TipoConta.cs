namespace Banco.Core.Enums;

public enum TipoConta
{
    Corrente = 1,
    Poupanca = 2
}
