using System.Security.Cryptography;
using System.Text;

namespace Banco.Application.Security;

public static class PasswordHasher
{
    public static (string Hash, string Salt) CriarHash(string senha)
    {
        var saltBytes = RandomNumberGenerator.GetBytes(16);
        var salt = Convert.ToHexString(saltBytes);
        return (CalcularHash(senha, salt), salt);
    }

    public static bool Verificar(string senha, string hashEsperado, string salt)
    {
        if (string.IsNullOrWhiteSpace(senha) || string.IsNullOrWhiteSpace(hashEsperado) || string.IsNullOrWhiteSpace(salt))
        {
            return false;
        }

        var hashCalculado = CalcularHash(senha, salt);
        return CryptographicOperations.FixedTimeEquals(
            Encoding.UTF8.GetBytes(hashCalculado),
            Encoding.UTF8.GetBytes(hashEsperado));
    }

    private static string CalcularHash(string senha, string salt)
    {
        var bytes = Encoding.UTF8.GetBytes($"{salt}:{senha}");
        return Convert.ToHexString(SHA256.HashData(bytes));
    }
}
