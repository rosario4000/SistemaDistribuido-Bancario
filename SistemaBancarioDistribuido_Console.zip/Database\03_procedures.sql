USE SistemaBancarioDistribuido;
GO

CREATE OR ALTER PROCEDURE dbo.sp_Depositar
    @NumeroConta VARCHAR(30),
    @Valor DECIMAL(18,2),
    @UtilizadorId INT,
    @Descricao NVARCHAR(250) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @Valor <= 0
        THROW 50001, 'Valor do deposito deve ser positivo.', 1;

    DECLARE @ContaId INT;
    DECLARE @AgenciaId INT;
    DECLARE @SaldoApos DECIMAL(18,2);
    DECLARE @Referencia VARCHAR(80) = CONCAT('DEP-', FORMAT(SYSUTCDATETIME(), 'yyyyMMddHHmmssfff'));

    BEGIN TRANSACTION;

    SELECT @ContaId = Id, @AgenciaId = AgenciaId
    FROM dbo.Contas WITH (UPDLOCK, ROWLOCK)
    WHERE Numero = @NumeroConta AND Estado = 'Ativa';

    IF @ContaId IS NULL
        THROW 50002, 'Conta nao encontrada ou indisponivel.', 1;

    UPDATE dbo.Contas
    SET Saldo = Saldo + @Valor
    WHERE Id = @ContaId;

    SELECT @SaldoApos = Saldo FROM dbo.Contas WHERE Id = @ContaId;

    INSERT INTO dbo.Transacoes (ContaId, AgenciaId, UtilizadorId, Tipo, Valor, SaldoApos, Referencia, Descricao)
    VALUES (@ContaId, @AgenciaId, @UtilizadorId, 'Deposito', @Valor, @SaldoApos, @Referencia, @Descricao);

    INSERT INTO dbo.Auditoria (UtilizadorId, AgenciaId, Acao, Entidade, EntidadeId, Detalhes)
    VALUES (@UtilizadorId, @AgenciaId, 'DEPOSITO', 'Conta', @ContaId, CONCAT('Deposito ', @Referencia));

    COMMIT TRANSACTION;
END
GO

CREATE OR ALTER PROCEDURE dbo.sp_Levantar
    @NumeroConta VARCHAR(30),
    @Valor DECIMAL(18,2),
    @UtilizadorId INT,
    @Descricao NVARCHAR(250) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @Valor <= 0
        THROW 50011, 'Valor do levantamento deve ser positivo.', 1;

    DECLARE @ContaId INT;
    DECLARE @AgenciaId INT;
    DECLARE @SaldoAtual DECIMAL(18,2);
    DECLARE @SaldoApos DECIMAL(18,2);
    DECLARE @Referencia VARCHAR(80) = CONCAT('LEV-', FORMAT(SYSUTCDATETIME(), 'yyyyMMddHHmmssfff'));

    BEGIN TRANSACTION;

    SELECT @ContaId = Id, @AgenciaId = AgenciaId, @SaldoAtual = Saldo
    FROM dbo.Contas WITH (UPDLOCK, ROWLOCK)
    WHERE Numero = @NumeroConta AND Estado = 'Ativa';

    IF @ContaId IS NULL
        THROW 50012, 'Conta nao encontrada ou indisponivel.', 1;

    IF @SaldoAtual < @Valor
        THROW 50013, 'Saldo insuficiente.', 1;

    UPDATE dbo.Contas
    SET Saldo = Saldo - @Valor
    WHERE Id = @ContaId;

    SELECT @SaldoApos = Saldo FROM dbo.Contas WHERE Id = @ContaId;

    INSERT INTO dbo.Transacoes (ContaId, AgenciaId, UtilizadorId, Tipo, Valor, SaldoApos, Referencia, Descricao)
    VALUES (@ContaId, @AgenciaId, @UtilizadorId, 'Levantamento', @Valor, @SaldoApos, @Referencia, @Descricao);

    INSERT INTO dbo.Auditoria (UtilizadorId, AgenciaId, Acao, Entidade, EntidadeId, Detalhes)
    VALUES (@UtilizadorId, @AgenciaId, 'LEVANTAMENTO', 'Conta', @ContaId, CONCAT('Levantamento ', @Referencia));

    COMMIT TRANSACTION;
END
GO

CREATE OR ALTER PROCEDURE dbo.sp_Transferir
    @ContaOrigem VARCHAR(30),
    @ContaDestino VARCHAR(30),
    @Valor DECIMAL(18,2),
    @UtilizadorId INT,
    @Descricao NVARCHAR(250) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @Valor <= 0
        THROW 50021, 'Valor da transferencia deve ser positivo.', 1;

    DECLARE @OrigemId INT;
    DECLARE @DestinoId INT;
    DECLARE @AgenciaOrigemId INT;
    DECLARE @AgenciaDestinoId INT;
    DECLARE @SaldoOrigem DECIMAL(18,2);
    DECLARE @SaldoOrigemApos DECIMAL(18,2);
    DECLARE @SaldoDestinoApos DECIMAL(18,2);
    DECLARE @Referencia VARCHAR(80) = CONCAT('TRF-', FORMAT(SYSUTCDATETIME(), 'yyyyMMddHHmmssfff'));

    BEGIN TRANSACTION;

    SELECT @OrigemId = Id, @AgenciaOrigemId = AgenciaId, @SaldoOrigem = Saldo
    FROM dbo.Contas WITH (UPDLOCK, ROWLOCK)
    WHERE Numero = @ContaOrigem AND Estado = 'Ativa';

    SELECT @DestinoId = Id, @AgenciaDestinoId = AgenciaId
    FROM dbo.Contas WITH (UPDLOCK, ROWLOCK)
    WHERE Numero = @ContaDestino AND Estado = 'Ativa';

    IF @OrigemId IS NULL OR @DestinoId IS NULL
        THROW 50022, 'Conta de origem ou destino nao encontrada.', 1;

    IF @OrigemId = @DestinoId
        THROW 50023, 'A conta de origem deve ser diferente da conta de destino.', 1;

    IF @SaldoOrigem < @Valor
        THROW 50024, 'Saldo insuficiente para transferencia.', 1;

    UPDATE dbo.Contas SET Saldo = Saldo - @Valor WHERE Id = @OrigemId;
    UPDATE dbo.Contas SET Saldo = Saldo + @Valor WHERE Id = @DestinoId;

    SELECT @SaldoOrigemApos = Saldo FROM dbo.Contas WHERE Id = @OrigemId;
    SELECT @SaldoDestinoApos = Saldo FROM dbo.Contas WHERE Id = @DestinoId;

    INSERT INTO dbo.Transferencias (ContaOrigemId, ContaDestinoId, UtilizadorId, Valor, Referencia)
    VALUES (@OrigemId, @DestinoId, @UtilizadorId, @Valor, @Referencia);

    INSERT INTO dbo.Transacoes (ContaId, AgenciaId, UtilizadorId, Tipo, Valor, SaldoApos, Referencia, Descricao)
    VALUES
        (@OrigemId, @AgenciaOrigemId, @UtilizadorId, 'TransferenciaEnviada', @Valor, @SaldoOrigemApos, @Referencia, @Descricao),
        (@DestinoId, @AgenciaDestinoId, @UtilizadorId, 'TransferenciaRecebida', @Valor, @SaldoDestinoApos, @Referencia, @Descricao);

    INSERT INTO dbo.Auditoria (UtilizadorId, AgenciaId, Acao, Entidade, EntidadeId, Detalhes)
    VALUES (@UtilizadorId, @AgenciaOrigemId, 'TRANSFERENCIA', 'Transferencia', SCOPE_IDENTITY(), CONCAT('Transferencia ', @Referencia));

    COMMIT TRANSACTION;
END
GO
