namespace Banco.Core.Enums;

public enum EstadoConta
{
    Ativa = 1,
    Bloqueada = 2,
    Encerrada = 3
}
